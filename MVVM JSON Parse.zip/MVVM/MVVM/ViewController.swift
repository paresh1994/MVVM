//
//  ViewController.swift
//  MVVM
//
//  Created by Paresh on 7/22/17.
//  Copyright © 2017 Paresh. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {

    static let cellID = "Cell"
    var movies = [Movie]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        
        self.tableView.register(MovieCell.self, forCellReuseIdentifier:
            ViewController.cellID)
        self.title = "Movie"
        
        self.tableView.estimatedRowHeight = 65
        self.tableView.rowHeight = UITableViewAutomaticDimension
        
        MovieRevices.sharedInstance.getNowPlayingMovies { [weak self]
            (result) in
            
            guard let strongSelf = self else {
                return
            }

            switch result {
                
            case .Success(let movies):
                for movie in movies {
                    
                    if let movie = movie {
                        strongSelf.movies.append(movie)
                    }
                }
                DispatchQueue.main.async {
                    strongSelf.tableView.reloadData()
                }
            case .Error(let error):
                print(error)
            }
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.movies.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ViewController.cellID, for: indexPath) as? MovieCell else {
            fatalError()
        }
        let movie = movies[indexPath.row]
        let imagePath = "https://image.tmdb.org/t/p/w342" + movie.posterPath
        cell.movieImageView.loadImageUsingCacheWithURLString(imagePath, placeHolder: nil) { (_) in }
        cell.movieTitleLabel.text = movie.title.uppercased()
        cell.dateLabel.text = "Release Date: " + movie.releaseDate
        cell.descriptionLabel.text =  movie.overview
        if let voteCount = movie.voteCount {
            cell.reviewsCountLabel.text = "Number Of Reviews \(voteCount)"
        }

        return cell
        
    }
    
}

