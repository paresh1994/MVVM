//
//  Movie.swift
//  MVVM
//
//  Created by Paresh on 7/22/17.
//  Copyright © 2017 Paresh. All rights reserved.
//

import UIKit

struct Movie {
    
    let title:String
    let posterPath:String
    let overview:String
    let releaseDate:String
    let voteCount:NSNumber?
    
}

extension Movie {
    
    struct Key {
        static let titleKey = "title"
        static let posterPathKey = "poster_path"
        static let overviewKey = "overview"
        static let releaseDateKey = "release_date"
        static let votesKey = "vote_count"
    }
    
    init?(json: [String: AnyObject]) {
        
        guard let title = json[Key.titleKey] as? String, let posterPath = json[Key.posterPathKey] as? String, let overview = json[Key.overviewKey] as? String, let releasedate = json[Key.releaseDateKey] as? String else {
            return nil
        }
        self.title = title
        self.posterPath = posterPath
        self.overview = overview
        self.releaseDate = releasedate
        self.voteCount = json[Key.votesKey] as? NSNumber
        
    }
}
