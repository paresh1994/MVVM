//
//  MovieRevices.swift
//  MVVM
//
//  Created by Paresh on 7/23/17.
//  Copyright © 2017 Paresh. All rights reserved.
//

import Foundation

struct MovieRevices {
    
    static let sharedInstance = MovieRevices()
    private init(){}
    
    // MARK: - properties and typealiases
    static let APIKey: String = "34a92f7d77a168fdcd9a46ee1863edf1"
    static let endPoint: String = "https://api.themoviedb.org/3/movie/now_playing?api_key="
    let downloader = JSONDownloader()
    
    //MAKE CHANGE HERE
    typealias MoviesNowPlayingCompletionHandler = (Result<[Movie?]>) -> ()
    
    func getNowPlayingMovies(completion: @escaping MoviesNowPlayingCompletionHandler) {
        
        guard let url = URL(string: MovieRevices.endPoint + MovieRevices.APIKey) else{
            completion(.Error(.invalidURL))
            return
        }
        
        let urlrequest = URLRequest(url: url)
        
        let task = downloader.jsonTask(with: urlrequest) { (result) in
            
            DispatchQueue.main.async {
                switch result {
                case .Success(let json):
                    guard let movie = json["results"] as? [[String: AnyObject]] else {
                        completion(.Error(.jsonParsingFailure))
                        return
                    }
                    
                    //MAKE CHANGE HERE
                    let movieArray = movie.map{Movie(json: $0)}
                    completion(.Success(movieArray))
                    
                    
                case .Error(let error):
                    completion(.Error(error))
                }
            }
            
        }
        task.resume()
    }
}
